const express=require('express');
//const bodyParser=require('body-parser');
const cors=require('cors');

const PORT=3001;

const app=express();
const mongoose=require('mongoose');
const user = require('./Models/user');
//app.use(bodyParser.json());

const db="mongodb+srv://varshaverma2:varshaverma2@cluster0.i0zai.mongodb.net/first?retryWrites=true&w=majority"
mongoose.Promise=global.Promise;
mongoose.connect(db,{useNewUrlParser: true,useUnifiedTopology: true},function(err){
if(err)
{console.log("error"+err);}
});

app.use(express.json());


app.use(cors());

app.get('/',function(req,res){
res.send('Hello from server');

})
app.post('/enroll',function(req,res){
//console.log(req.body);
//res.status(401).send({"message":"data received"});
var newUser=new user();
newUser.userName=req.body.userName;
newUser.email=req.body.email;
newUser.password=req.body.password;
newUser.confirmPassword=req.body.confirmPassword;
newUser.address.city=req.body.address.city;
newUser.address.state=req.body.address.state;
newUser.address.postalCode=req.body.address.postalCode; 
    newUser.save(function(err,insertedUser){
        if(err){
            console.log('Error saving User')
        }
        else{
            console.log(insertedUser);
            res.json(insertedUser)
        }
    })
})

app.listen(PORT,function(){
console.log("server running on localhost"+PORT);

});