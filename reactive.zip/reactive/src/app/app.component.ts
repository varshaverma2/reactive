import { Component } from '@angular/core';
import { FormBuilder,Validators,FormArray } from '@angular/forms';
import { RegistrationService } from './registration.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  get alternateEmails(){
    return this.registrationForm.get('alternateEmails') as FormArray
  }
  addalternateEmails(){
    this.alternateEmails.push(this.fb.control(''));
  }
constructor(private fb:FormBuilder, private _registrationService:RegistrationService){}
registrationForm=this.fb.group({
  userName:['',Validators.required],
  email:[''],
  password:[''],
  confirmPassword:[''],
  address:this.fb.group({
    city: [''],
    state: [''],
    postalCode: ['']
  }),
 alternateEmails:this.fb.array([]) 
});


  /*registrationForm=new FormGroup({
 userName:new FormControl(''),
 password:new FormControl(''),
 confirmPassword:new FormControl(''),
 address:new FormGroup({
 city: new FormControl(''),
 state: new FormControl(''),
 postalCode: new FormControl(''),
 })
}); */
  
 loadApiData()
 {
   this.registrationForm.patchValue({
  userName:'Varsha',
  email:'abc@gmail',
  password:'test',
  confirmPassword:'test',
  address:{
  city:'City',
  state:'State',
  postalCode:'123456'
  }

   });
 }
 onSubmit(){
   this._registrationService.register(this.registrationForm.value).subscribe(
     response => console.log('Success!',response),
     error => console.error('Error!',error)
   );
 }
}
